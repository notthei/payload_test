<footer>
<hr>
<p>Copyright 2020</p>
</footer>
</body>
</html>