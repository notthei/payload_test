<?php
$token = random_bytes(20);
echo $token;